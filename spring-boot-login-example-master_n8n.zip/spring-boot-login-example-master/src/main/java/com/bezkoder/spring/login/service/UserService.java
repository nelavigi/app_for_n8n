package com.bezkoder.spring.login.service;

import com.bezkoder.spring.login.models.User;
import com.bezkoder.spring.login.payload.request.LoginRequest;
import com.bezkoder.spring.login.payload.request.SignupRequest;

public interface UserService {
    User registerUser(SignupRequest request) throws Exception;

    boolean validateLogin(LoginRequest request);
}

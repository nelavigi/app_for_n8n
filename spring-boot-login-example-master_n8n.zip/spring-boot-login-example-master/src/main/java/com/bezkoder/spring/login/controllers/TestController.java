package com.bezkoder.spring.login.controllers;

import com.bezkoder.spring.login.payload.request.LoginRequest;
import com.bezkoder.spring.login.payload.request.SignupRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

// Simple controller to serve Thymeleaf login/register pages and basic form handling.
@CrossOrigin(origins = "*", maxAge = 3600)
@Controller
@RequestMapping("/")
public class TestController {

  @Autowired
  private com.bezkoder.spring.login.service.UserService userService;

  @GetMapping
  public String home() {
    return "index"; // optional home page
  }

  @GetMapping("login")
  public String showLoginForm(Model model) {
    model.addAttribute("loginRequest", new LoginRequest());
    return "login";
  }

  @PostMapping("login")
  @ResponseBody
  public ResponseEntity<java.util.Map<String, Object>> doLogin(LoginRequest loginRequest) {
    java.util.Map<String, Object> body = new java.util.HashMap<>();
    if (loginRequest == null || loginRequest.getEmail() == null || loginRequest.getEmail().trim().isEmpty()
        || loginRequest.getPassword() == null || loginRequest.getPassword().isEmpty()) {
      body.put("success", false);
      body.put("message", "Email and password are required");
      return ResponseEntity.status(org.springframework.http.HttpStatus.BAD_REQUEST).body(body);
    }

    boolean ok = userService.validateLogin(loginRequest);
    if (!ok) {
      body.put("success", false);
      body.put("message", "Invalid email or password");
      return ResponseEntity.status(org.springframework.http.HttpStatus.UNAUTHORIZED).body(body);
    }

    body.put("success", true);
    body.put("message", "Login successful");
    return ResponseEntity.ok(body);
  }

  @GetMapping("register")
  public String showRegistrationForm(Model model) {
    model.addAttribute("signupRequest", new SignupRequest());
    return "register";
  }

  @PostMapping("register")
  @ResponseBody
  public ResponseEntity<java.util.Map<String, Object>> doRegister(SignupRequest signupRequest) {
    java.util.Map<String, Object> body = new java.util.HashMap<>();

    try {
      userService.registerUser(signupRequest);
      body.put("success", true);
      body.put("message", "User registered successfully");
      return ResponseEntity.ok(body);
    } catch (Exception e) {
      body.put("success", false);
      body.put("message", e.getMessage());
      return ResponseEntity.status(HttpStatus.CONFLICT).body(body);
    }
  }

  
  
}

package com.bezkoder.spring.login.service.impl;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.bezkoder.spring.login.models.ERole;
import com.bezkoder.spring.login.models.Role;
import com.bezkoder.spring.login.models.User;
import com.bezkoder.spring.login.payload.request.LoginRequest;
import com.bezkoder.spring.login.payload.request.SignupRequest;
import com.bezkoder.spring.login.repository.RoleRepository;
import com.bezkoder.spring.login.repository.UserRepository;
import com.bezkoder.spring.login.service.UserService;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    // using jBCrypt directly

    @Override
    public User registerUser(SignupRequest request) throws Exception {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new Exception("Error: Email is already in use!");
        }

        // Create user account (username may be non-unique)
        User user = new User(request.getUsername(), request.getEmail(), request.getPassword());

        Set<Role> roles = new HashSet<>();
        // default role USER
        Optional<Role> userRole = roleRepository.findByName(ERole.ROLE_USER);
        if (userRole.isPresent()) {
            roles.add(userRole.get());
        } else {
            // create role if missing
            Role newRole = new Role(ERole.ROLE_USER);
            roleRepository.save(newRole);
            roles.add(newRole);
        }

        user.setRoles(roles);
        return userRepository.save(user);
    }

    @Override
    public boolean validateLogin(LoginRequest request) {
        Optional<User> userOpt = userRepository.findByEmail(request.getEmail());
        if (userOpt.isEmpty()) return false;
        User user = userOpt.get();
        return request.getPassword().equals(user.getPassword());
    }
}
